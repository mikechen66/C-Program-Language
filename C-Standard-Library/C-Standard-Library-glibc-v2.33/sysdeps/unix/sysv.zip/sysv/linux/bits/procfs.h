#error "This file must be supplied by each architecture using it."
