#include <sysdeps/unix/sysv/linux/fstatvfs.c>
