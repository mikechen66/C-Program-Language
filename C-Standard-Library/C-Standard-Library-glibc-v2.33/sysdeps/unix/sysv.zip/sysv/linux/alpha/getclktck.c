#define SYSTEM_CLK_TCK	1024
#include <sysdeps/unix/sysv/linux/getclktck.c>
