#include "dl-auxv.h"

long __libc_alpha_cache_shape[4] = { -2, -2, -2, -2 };

#include <sysdeps/unix/sysv/linux/dl-sysdep.c>
