/* A copy of the couple of bits we need from <asm/sysinfo.h>.  */

#define GSI_IEEE_FP_CONTROL		45

#define SSI_IEEE_FP_CONTROL		14
#define SSI_IEEE_RAISE_EXCEPTION	1001
