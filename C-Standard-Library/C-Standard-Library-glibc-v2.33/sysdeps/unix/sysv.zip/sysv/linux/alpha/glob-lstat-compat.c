#define GLOB_LSTAT_VERSION GLIBC_2_1
#include <sysdeps/unix/sysv/linux/glob-lstat-compat.c>
