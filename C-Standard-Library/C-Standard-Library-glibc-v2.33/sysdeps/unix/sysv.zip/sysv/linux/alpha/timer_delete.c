#include <sysdeps/unix/sysv/linux/x86_64/timer_delete.c>
