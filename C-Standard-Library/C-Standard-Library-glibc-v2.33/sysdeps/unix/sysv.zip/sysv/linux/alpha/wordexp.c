#include <sysdeps/unix/sysv/linux/sparc/sparc64/wordexp.c>
